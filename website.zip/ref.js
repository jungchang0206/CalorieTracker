'use strict';

/** @type {import('./ref')} */
module.exports = ReferenceError;
